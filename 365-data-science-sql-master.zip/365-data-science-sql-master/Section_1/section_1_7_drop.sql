drop table tutorial.employees;
drop table tutorial.employees_two;